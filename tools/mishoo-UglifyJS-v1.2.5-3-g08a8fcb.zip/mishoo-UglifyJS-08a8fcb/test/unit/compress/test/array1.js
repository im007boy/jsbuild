new Array();
new Array(1);
new Array(1, 2, 3);
